#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef char *Word;

typedef struct node{ 
    Word word; 
    int *lines, occurrences, *positions, depth;
    struct node *left, *right;

}*Link; 


Link insertNode (Link root, Word aux_word, int line, int nlines, int position);
Link newNode (Word aux_word, int line, int nlines, int position);
Link updateNode (Link root, int line, int position);
void traverse (Link root);
void visit (Link root);
int wordCompare (Word word1, Word word2);
void deleteTree (Link root);
Link deleteWord (Link root, Word word);
Link deleteLink (Link root);
void deleteNode (Link root);
Link maxLeftChild (Link root);
Link maxLeftFather (Link root, Link temp);
Link lookUp (Link root, Word word);
int getDepth (Link root, int depth);
int balanceFactor(Link root);
Link testBranch (Link root);
Link balanceTree (Link root, int bfactor);
Link rotateLeft (Link root);
Link rotateRight (Link root);
Link doubleRotateRL (Link root);
Link doubleRotateLR (Link root);

