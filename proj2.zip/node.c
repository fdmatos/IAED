#include "node.h"


Link insertNode (Link root, Word aux_word, int line, int nlines, int position)
{

	if (root == NULL)
		root = newNode (aux_word, line, nlines, position);							/* se não existir, é criado um node para a nova palavra */
	

	else if (!wordCompare(aux_word, root->word))									/* se existir, os seus campos são actualizados */
		root = updateNode(root, line, position);

	else if (wordCompare(aux_word, root->word) > 0)									/* a árvore é percorrida até chegar á posição onde a palavra está ou deve ser inserida */
		root->right = insertNode (root->right, aux_word, line, nlines, position);

	else
		root->left = insertNode (root->left, aux_word, line, nlines, position);

	return testBranch (root);														/* o ramo vai ser testado desde o novo node á raiz porque a inserção pode ter desiquilibrado a árvore */
}


Link newNode (Word aux_word, int line, int nlines, int position)
{
	Link newlink = (Link) malloc (sizeof(struct node));							/*	reserva memória para a estrutura, a palavra, o vector com linhas e o vector com posições */
	newlink->word = (Word) malloc (sizeof(char)*strlen(aux_word) + 1);
	strcpy(newlink->word, aux_word);

	newlink->lines = (int*) malloc (sizeof(int)*nlines);								/* os vectores para as linhas e posições são inicializados com espaço para uma célula */
	newlink->positions = (int*) malloc (sizeof(int));
	
	newlink->lines[0] = line;													/* e é guardada a linha e posição da 1ª ocorrência nessa célula */
	newlink->positions[0] = position;

	newlink->occurrences = 1;													

	newlink->left = NULL;																								
	newlink->right = NULL;

	return newlink;
}

Link updateNode (Link root, int line, int position)
{	
	root->occurrences++;																	/* se a palavra já estiver inserida na árvore então incrementa as ocorrências */

	root->positions = (int*) realloc (root->positions, sizeof(int)*(root->occurrences));

	root->lines[root->occurrences-1] =  line;	
	root->positions[root->occurrences-1] = position;										/* guarda a linha onde ocorreu novamente e a sua posição nessa linha */
	return root;
}

void traverse (Link root)
{
	if (root == NULL)												/* faz uma travessia in order que imprime a árvore alfabeticamente */
		return;		

	traverse(root->left);
	visit(root);
	traverse(root->right);
}

void visit (Link root)
{
	printf("%s %d\n", root->word, root->occurrences);	
}


int wordCompare (Word word1, Word word2)
{		
	int cmax, b;

	cmax = strlen(word1);
	b = strlen(word2);

	cmax = (b > cmax) ? b : cmax;						/* cmax fica com o maior dos comprimentos das strings */

	return strncmp(word1, word2, cmax); 				/* devolve > 0 se a 1ª string for > que a 2ª */

}

Link deleteWord (Link root, Word word)
{
	if (root != NULL)
	{
		if (!wordCompare(word, root->word))					/* percorre a árvore até encontrar um node com a palavra correspondente */
			root = deleteLink(root);

		else if (wordCompare(word, root->word) > 0)
			root->right = deleteWord(root->right, word);

		else 
			root->left = deleteWord(root->left, word);
	}

	return testBranch(root);
}


Link deleteLink (Link root)
{
	Link aux, temp;

	if (root->right != NULL && root->left != NULL)		/* caso o node a apagar tenha dois filhos */
	{
		aux = maxLeftChild(root->left);					/* o maior filho do ramo esquerdo */

		if (root->left->right != NULL)
			temp = maxLeftFather(root->left, NULL);     /* o pai do maior filho do ramo esquerdo */

		else
			temp = root;

		temp->right = aux->left;						/* o filho esquerdo de aux toma a sua posição (que é agora o maior filho do ramo esquerdo) */

		aux->right = root->right;						/* o aux vai tomar a posição da raiz e portante assume o seu filho direito */

		if (root->left != aux)							/* e também o seu filho esquerdo (se não for ele próprio) */
			aux->left = root->left;

	}

	else if (root->right == NULL && root->left == NULL)	/* caso o node a apagar não tenha nenhum filho */
		aux = NULL;

	else if (root->right != NULL)						/* caso tenha apenas o filho direito */
		aux = root->right;

	else
		aux = root->left;								/* caso tenha apenas o filho esquerdo */

	deleteNode(root);
	return aux;
}

void deleteNode (Link root)
{
	free(root->lines);						/* liberta a memória alocada para a palavra, o vector das linhas, */
	free(root->word);						/* o vector com posições e a estrutura */
	free(root->positions);	
	free(root);
}

void deleteTree (Link root)
{
	if (root == NULL)
		return;

	deleteTree(root->left);					/* liberta a memória alocada para a árvore */
	deleteTree(root->right);
	deleteNode(root);

}

Link maxLeftChild (Link root)
{
	if (root->right == NULL)
		return (root);							/* encontra o maior filho do ramo esquerdo */

	return maxLeftChild(root->right);
}

Link maxLeftFather (Link root, Link temp)
{
	if (root->right == NULL)
		return temp;							/* encontra o pai do maior filho do ramo esquerdo */

	temp = root;

	return maxLeftFather(root->right, temp);
}

Link lookUp (Link root, Word word)
{

	if (root == NULL)
		return root;

	else if (!wordCompare(root->word, word))			/* compara a palavra com o node em que está */
		return root;

	else if (wordCompare(root->word, word) > 0)			/* se for menor então está no ramo esquerdo */
		return lookUp (root->left, word);

	else
		return lookUp (root->right, word);				/* se for maior então está no ramo direito */
}

int getDepth (Link root, int depth)
{
	int a, b;

	if (root == NULL)
		return depth;

	else 
	{	
		a = getDepth(root->left, depth+1);		/* obtém a profundidade de um ramo percorrendo recursivamente cada ramo (esquerdo e direito) */

		b = getDepth(root->right, depth+1);			

		return (a > b) ? a : b;					/* e retornando a profundidade do maior dos dois ramos */
	}
}

int balanceFactor (Link root)
{
	if (root == NULL)							/* calcula o balance factor através da diferença entre */
		return 0;								/* a profundidade do filho esquerdo e direito */

	return (getDepth(root->left, 0) - getDepth(root->right, 0));	
}

Link testBranch (Link root)
{
	int bfactor;

	if (abs(bfactor = balanceFactor(root)) > 1)			/* testa se o node está desiquilibrado ( |bfactor| > 1 ) */
		return balanceTree(root, bfactor);				/* equilibra se estiver */

	return root;
}


Link balanceTree (Link root, int bfactor)
{
	if (bfactor < -1)										/* se o ramo desiquilibrado é o da direita */
		{
			if (balanceFactor (root->right) >= 1)			/* caso haja um "cotovelo" com abertura para a direita */
				return doubleRotateRL (root);			

			else 
				return rotateLeft (root);					/* caso haja uma recta com declive negativo */
		}
	else 														/* se o ramo desiquilibrado é o da esquerda */
		{
			if (balanceFactor (root->left) <= -1 )				/* caso haja um "cotovelo" com abertura para a esquerda */
				return doubleRotateLR (root);

			else 
				return rotateRight (root);						/* caso haja uma recta com declive positivo  */
		}
	return root;
}

Link doubleRotateRL (Link root)
{
	root->right = rotateRight(root->right);				/* rotaçao dupla direita - esquerda */
	return rotateLeft(root);
}

Link doubleRotateLR (Link root)
{
	root->left = rotateLeft(root->left);				/* rotaçao dupla esquerda - direita */
	return rotateRight(root);	
}

Link rotateLeft (Link root)
{
	Link aux = root->right;								/* rotação simples esquerda */
	root->right = aux->left;
	aux->left = root;

	return aux;
}
	
Link rotateRight (Link root)
{														/* rotação simples direita */
	Link aux = root->left;
	root->left = aux->right;
	aux->right = root;

	return aux;

}

