# include "main.h"

int main()
{
	int nlines;
	char **text;
	Link root = NULL;

	scanf("%d\n", &nlines);								/* obtém o nº de linhas a serem lidas */
	text = (char**) malloc (sizeof(char*)*nlines);		/* aloca memória para o texto */
	root = insertLines(text, nlines, root);				/* insere a linha no texto e na árvore (palavra a palavra) */

	root = executeCommands(root, text, nlines);			/* recebe e executa comandos referentes ao texto */

	erase (root, text, nlines);							/* liberta toda a memória alocada pelo programa (árvore e texto) */
	return 0;
}

Link executeCommands (Link root, char** text, int nlines)
{
	char c;

	while (scanf("%c", &c) > 0)
		switch (c)
		{
			case 'f':
				root = F_command (root);					/* apaga uma palavra da árvore */
				break;

			case 's':
				S_command (text, nlines);					/* lista o texto original */
				break;

			case 'l':
				L_command (root, text, nlines);						/* lista as linhas em que a palavra ocorre */
				break;

			case 'w':
				W_command (root, text, nlines);						/* lista as linhas em que as palavras aparecem consecutivamente */
				break;

			case 'h':
				H_command (root);							/* imprime todas as palavras na árvore alfabeticamente */
				break;

			default:
				return root;
		}
	
	return root;
}

Link F_command (Link root)
{		
	char *word;

	getchar();										/* apanha o "espaço" entre o comando e o argumento */
	word = getline ();								/* obtém a palavra a apagar */
	root = deleteWord (root, word);					/* apaga o node respectivo na árvore */
	free(word);

	return root;	
}

void L_command (Link root, char **text, int nlines)
{
	int i, *printedLines, nPrintedLines = 1;
	Link node;
	char *word;

	getchar();											/* apanha o "espaço" entre o comando e o argumento */
	word = getline ();									/* obtém a palavra a listar */
	node = lookUp (root, word);							/* procura o node respectivo na árvore */

	if (node == NULL)		
	{
		free(word);										/* se a palavra não se encontrar na árvore, então */
		return;											/* liberta apenas a memória alocada para a palavra */
	}	

	printedLines = (int*) malloc (sizeof(int)*nlines);
	printedLines[0] = -1;

	for (i = 0; i < node->occurrences; ++i)  											/* lista todas a linhas em que a palavra ocorre */
		if (testLine (printedLines, nPrintedLines, node->lines[i]))
		{
			printf("%d %s\n", node->lines[i], text[node->lines[i]-1]);
			
			printedLines[nPrintedLines-1] = node->lines[i];								/* guarda o nº da linha imprimida para não a imprimir duas vezes*/
			nPrintedLines++;															/* aumenta o nº de linhas imprimidas */
			printedLines[nPrintedLines-1] = -1;											/* inicializa a célula com um valor "absurdo" apesar de nunca ser testado*/
		}

	free (word);	
	free (printedLines);
}

void W_command (Link root, char **text, int nlines)
{
	int i, e, *printedLines, nPrintedLines = 1;
	Link  Node1, Node2;
	char *line, *word1, *word2;

	line = getline();									/* obtém a linha com os argumentos */

	word1 = strtok (line, " ,\t.;?!""\n");			/* obtém a 1ª palavra */
	word2 = strtok (NULL, " ,\t.;?!\n");			/* obtém a 2ª palavra */

	Node1 = lookUp (root, word1);						/* obtém o node da árvore respectivo á 1ª palavra */
	Node2 = lookUp (root, word2);						/* obtém o node da árvore respectivo á 2ª palavra */

	if (Node1 == NULL || Node2 == NULL)					/* se algum dos nodes tiver sido apagado ou nunca tiver sido inserido */
	{
		free (line);
		return;
	}

	printedLines = (int*) malloc (sizeof(int)*nlines);			/* aloca memória para guardar uma linha */
	printedLines[0] = -1;								/* para sinalizar que não foi guardada nenhuma linha */


	for (i = 0; i < Node1->occurrences; ++i)											/* compara as posições das palavras e se houver possibilidade */
		for (e = 0; e < Node2->occurrences; ++e)									/* de serem consecutivas testa se a linha é igual */
			if (Node1->lines[i] == Node2->lines[e] && testLine(printedLines, nPrintedLines, Node1->lines[i])) 	/* se a linha for igual e não tiver sido imprimida*/
				if (Node1->positions[i] == (Node2->positions[e] - 1) || Node1->positions[i] == (Node2->positions[e] + 1))
			{
				printf("%d %s\n",Node1->lines[i], text[Node1->lines[i]-1]);				/* os indices do texto começam em 0 e as linhas em 1 */

				printedLines[nPrintedLines-1] = Node1->lines[i];									/* guarda o nº da linha imprimida para não a imprimir duas vezes*/
				nPrintedLines++;																	/* aumenta o nº de linhas imprimidas */
				printedLines[nPrintedLines-1] = -1;													/* inicializa a célula com um valor "absurdo" apesar de nunca ser testado*/

			}

	free (line);
	free (printedLines);
}

int testLine (int *printedLines, int nPrintedLines, int line)
{
	int i;

	for (i = 0; i < nPrintedLines; ++i)												/* testa se a linha a ser imprimida já se encontra no vector */
		if (printedLines[i] == line)											/* de linhas préviamente imprimidas */
			return 0;

	return 1;
}


void H_command (Link root)
{
	traverse(root);
	getchar();											/* apanha o '\n' */
}

void S_command (char** text, int nlines)
{
	int i;

	for (i = 0; i < nlines; ++i)								/* imprime o texto original inalterado */
		printf("%s\n", text[i]);			

	getchar();            										/* apanha o '\n' */
}

char* getline ()
{
	int i;
	char c, line[MAXCHARS], *p_line;

	for (i = 0; (c = getchar()) != '\n'; i++)			/* lê uma linha do terminal */
		line[i] = c;

	line[i] = '\0';

	p_line = (char*) malloc (sizeof(char)*(strlen(line)+1)); 
	strcpy (p_line, line);								/* aloca a memória necessária para a linha */		

	return p_line;										/* retorna um char* com a linha */
}

Link insertLines (char **text, int nlines, Link root)
{	
	int i, position = 1;
	Word line, aux_word;

	for (i = 0; i < nlines; ++i)
	{		
		line = getline();										/* lê uma linha */			
		text[i] = (char*) malloc (sizeof(char)*(strlen(line)+1));	
		strcpy(text[i], line);									/* insere a linha no texto */

		aux_word = strtok (line, " ,\t.;?!""\n");				/* parte a linha em palavras */

		while (aux_word != NULL) 
		{
			aux_word = convertLower (aux_word);
			root = insertNode (root, aux_word, i+1, nlines, position);    /* insere as palavras na árvore */
			aux_word = strtok (NULL, " ,\t.;?!""\n");			
			position++;
		}
		free(line);
	}

	return root;											  /* devolve a raiz com a árvore actualizada */
}

void erase (Link root, char** text, int nlines)
{
	int i;

	for (i = 0; i < nlines; ++i)
		free(text[i]);										/* apaga toda a memória alocada pelo programa */

	free(text);
	deleteTree(root);
}

Word convertLower (Word word)
{
	int i, len = strlen(word);								/* converte os caracteres alfabéticos maiusculos para minusculos */

	for(i = 0; i < len; i++)
 		word[i] = tolower(word[i]);

 	return word;

}